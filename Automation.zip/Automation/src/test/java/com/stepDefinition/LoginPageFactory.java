package com.stepDefinition;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageFactory {

	WebDriver driver;
	
	public LoginPageFactory(WebDriver driver) {
		
		this.driver = driver;
	    PageFactory.initElements(driver,this);
			
	}
	
	public void Opensite() throws InterruptedException
	{
		driver.get("https://www.zara.com/in/");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//*[contains(@id, 'onetrust-close-btn-container') ]")).click();
	}


	//Login Create Account

	@FindBy(xpath="//*[contains(text(), 'LOG IN')]")
	@CacheLookup
    WebElement loginbtn;
	
	@FindBy(xpath="//*[@class='button__lines-wrapper']")
	@CacheLookup
    WebElement createaccbtn;
	
	@FindBy(xpath="//*[contains(@name, 'email')]")
	@CacheLookup
    WebElement regemail;
	
	@FindBy(xpath="//*[contains(@name, 'password')]")
	@CacheLookup
    WebElement regpass;
	
	@FindBy(xpath="//*[contains(@name, 'passwordConfirm')]")
	@CacheLookup
    WebElement regrepeatpass;
	
	@FindBy(xpath="//*[contains(@name, 'firstName')]")
	@CacheLookup
    WebElement regname;
	
	@FindBy(xpath="//*[contains(@name, 'addressLines[0]')]")
	@CacheLookup
    WebElement regaddress;
	
	@FindBy(xpath="//*[contains(@name, 'city')]")
	@CacheLookup
    WebElement regcity;
	
	@FindBy(xpath="//*[contains(@name, 'stateCode')]")
	@CacheLookup
    WebElement regstate;
	
	@FindBy(xpath="//*[contains(@name, 'zipCode')]")
	@CacheLookup
    WebElement regpin;
	
	@FindBy(xpath="//*[contains(@name, 'phones[0].subscriberNumber')]")
	@CacheLookup
    WebElement regphone;
	
	//Login
	
	@FindBy(xpath="//input[@name='logonId']")
	@CacheLookup
	WebElement loginemail;
	
	@FindBy(xpath="//input[@name='password']")
	@CacheLookup
	WebElement loginpass;
	
    
	//Hamburger
	
	@FindBy(xpath="//*[contains(@aria-label, 'Open menu')]")
	@CacheLookup
	WebElement openham;
	
	@FindBy(xpath="//*[contains(@data-categoryid, '1561886')]")
	@CacheLookup
	WebElement womansec;
	
	@FindBy(xpath="//*[contains(@aria-label, 'TOPS')]")
	@CacheLookup
	WebElement womansectop;
	
	
	//Search
	
	@FindBy(xpath="//*[contains(@class,'layout-header-search-bar__text')]")
	@CacheLookup
	WebElement search;
	
	@FindBy(xpath="//*[contains(@class,'selected')]")
	@CacheLookup
	WebElement womansecsearch;
	
	@FindBy(xpath="//*[contains(@placeholder,'Enter search terms')]")
	@CacheLookup
	WebElement searchitem;
	
	
	//Search filter
	
	@FindBy(xpath="//*[contains(text(),'Filters')]")
	@CacheLookup
	WebElement filter;
	
	@FindBy(xpath="//*[contains(text(),'CHARACTERISTICS')]")
	@CacheLookup
	WebElement filterchar;
	
	@FindBy(xpath="//*[contains(@data-qa-input-qualifier,'Corset')]")
	@CacheLookup
	WebElement filtercharopt;
	
	@FindBy(xpath="//*[contains(button,'Colour')]")
	@CacheLookup
	WebElement filtercolour;
	
	@FindBy(xpath="//*[contains(text(),'Fuchsia')]")
	@CacheLookup
	WebElement filtercolouropt;
	
	@FindBy(xpath="//*[contains(button,'SIZE')]")
	@CacheLookup
	WebElement filtersize;
	
	@FindBy(xpath="//*[contains(label,'XS')]")
	@CacheLookup
	WebElement filtersizeopt;
	
	@FindBy(xpath="//*[contains(@class,'filters-panel__button-close')]")
	@CacheLookup
	WebElement closefilter;
	
	//Checkout 
	
	@FindBy(xpath="//*[contains(@alt,'Image 0 of CROPPED CORSETRY-INSPIRED TOP from Zara')]")
	@CacheLookup
	WebElement womentop;
	
	@FindBy(xpath="//*[contains(@id,'product-size-selector-182853025-item-0')]")
	@CacheLookup
	WebElement womentopsize;
	
	@FindBy(xpath="//*[contains(@aria-label,'Add to bag CROPPED CORSETRY-INSPIRED TOP')]")
	@CacheLookup
	WebElement addtobag;
	
	@FindBy(xpath="//*[contains(@class,'layout-header-links__cart-items-count')]")
	@CacheLookup
	WebElement bag;

	
	//GetterSetter
	
	public void setregemail(String email)
	{
		regemail.sendKeys(email);
	}
	
	public WebElement getregemail()
	{
		return regemail;
	}
	
	public void setregepass(String pass)
	{
		regpass.sendKeys(pass);
	}
	
	public WebElement getregpass()
	{
		return regpass;
	}
	
	public void setregrepeatpass(String repeatpass)
	{
		regrepeatpass.sendKeys(repeatpass);
	}
	
	public WebElement getregrepeatpass()
	{
		return regrepeatpass;
	}
	
	public void setregname(String name)
	{
		regname.sendKeys(name);
	}
	
	public WebElement getregname()
	{
		return regname;
	}
	
	public void setregaddress(String address)
	{
		regaddress.sendKeys(address);
	}
	
	public WebElement getregaddress()
	{
		return regaddress;
	}
	
	public void setregcity(String city)
	{
		regcity.sendKeys(city);
	}
	
	public WebElement getregcity()
	{
		return regcity;
	}
	
	
	public void setregpin(String pin)
	{
		regpin.sendKeys(pin);
	}
	
	public WebElement getregpin()
	{
		return regpin;
	}
	
	public void setregphone(String phone)
	{
		regphone.sendKeys(phone);
	}
	
	public WebElement getregphone()
	{
		return regphone;
	}
	
	
	public void setloginemail(String logemail)
	{
		loginemail.sendKeys(logemail);
	}
	
	public WebElement getloginemail()
	{
		return loginemail;
	}
	
	public void setloginpass(String logpass)
	{
		loginpass.sendKeys(logpass);
	}
	
	public WebElement getloginpass()
	{
		return loginpass;
	}
	
	public void setsearch(String searchit)
	{
		searchitem.sendKeys(searchit);
	}
	
	public WebElement getsearch()
	{
		return searchitem;
	}
		
		
	
}
