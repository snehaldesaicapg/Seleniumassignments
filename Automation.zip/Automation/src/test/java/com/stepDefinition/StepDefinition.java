package com.stepDefinition;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class StepDefinition {

    WebDriver driver = new ChromeDriver();
    LoginPageFactory obj= new LoginPageFactory(driver);;
    WebDriverWait wait;
    

		@Given("User is on login page")
		public void user_is_on_login_page() throws InterruptedException {
		    
		    System.setProperty("webdriver.chrome.driver", "C:\\Users\\snedesai\\eclipse-workspace\\chromedriver\\chromedriver.exe");
		    ChromeOptions options = new ChromeOptions();
		    options.addArguments("--disable-notifications");
		
		    obj.Opensite();
		
		    System.out.println("On homepage");
		    Thread.sleep(3000);   
		    
		    obj.loginbtn.click();
		    Thread.sleep(3000);       
		}

		@When("I click on create account")
		public void i_click_on_create_account() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
			
			obj.createaccbtn.click();
			Thread.sleep(3000);
			
		}

		@Then("I will go on register page")
		public void i_will_go_on_register_page() throws InterruptedException {
		    
			System.out.println("On register page");
		}
		
		@And("I fill all details and click on create account button")
		public void i_fill_all_details_and_click_on_create_account_button() throws InterruptedException {
		    
		    
			Thread.sleep(2000);
			obj.setregemail("snehal.desai.1220@gmail.com");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			obj.setregepass("Snehal12");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			obj.setregrepeatpass("Snehal12");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			obj.setregname("Snehal");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			obj.setregcity("Pune");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			obj.setregaddress("Chinchwad");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			obj.setregpin("412114");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			obj.regstate.click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[contains(@value, 'INMH')]")).click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			obj.setregphone("8830155621");
			Thread.sleep(4000);
			
			WebElement clickbtn = driver.findElement(By.xpath("//input[@name='privacyCheck']"));
			boolean isselected = clickbtn.isSelected();
			System.out.println(isselected);
			if(isselected == false) {
				
				for(int i=0;i<2;i++) {
				clickbtn.click();			
				}
			}
			
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			//Thread.sleep(3000);
			driver.findElement(By.xpath("//*[contains(@role, 'button')]")).click();	
			
		}


		@Then("account will be created")
		public void account_will_be_created() {
		    // Write code here that turns the phrase above into concrete actions
		    
			System.out.println("Account created");
		}
		
		
		@When("I enter email and password")
		public void i_enter_email_and_password() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
		    
		    obj.setloginemail("snehal.desai.1220@gmail.com");
		    Thread.sleep(2000);
		    obj.setloginpass("Abc12345");
		       
		}

		@And("click on login button")
		public void click_on_login_button() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
			Thread.sleep(2000);
		    driver.findElement(By.xpath("//*[contains(@class,'zds-button__lines-wrapper')]")).click();
		}

		@Then("I should be able to login to my account")
		public void i_should_be_able_to_login_to_my_account() {
		    // Write code here that turns the phrase above into concrete actions
			System.out.println("Loggedin");
			
		    throw new io.cucumber.java.PendingException();
		}
		
		@Given("User is on home page")
		public void user_is_on_home_page() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
		    obj.Opensite();
		}
		
		@When("I click on hamburger menu")
		public void i_click_on_hamburger_menu() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
			obj.openham.click();
			Thread.sleep(3000);
		}

		@Then("sidebar should appear")
		public void sidebar_should_appear() {
		    // Write code here that turns the phrase above into concrete actions
			
		   System.out.println("Sidebar");
		}

		@And("when I click on woman option and tops")
		public void when_i_click_on_woman_option_and_tops() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
			obj.womansec.click();
			Thread.sleep(2000);
			obj.womansectop.click();
		    Thread.sleep(3000);  
		}

		@Then("tops page should be displayed")
		public void tops_page_should_be_displayed() {
		    // Write code here that turns the phrase above into concrete actions
		    System.out.println("Tops page");
		}
		
		@When("I click on search")
		public void i_click_on_search() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
		    obj.search.click();
		    Thread.sleep(2000);
		}

		@Then("I should get the search page")
		public void i_should_get_the_search_page() {
		    // Write code here that turns the phrase above into concrete actions
			System.out.println("On search page");
		}

		@And("when I select from woman or man or kids and enter search item")
		public void when_i_select_from_woman_or_man_or_kids_and_enter_search_item() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
		    
			obj.womansecsearch.click();
			Thread.sleep(2000);
			obj.setsearch("dresses");
				
		}

		@Then("I should get the required item")
		public void i_should_get_the_required_item() {
		    // Write code here that turns the phrase above into concrete actions
		   System.out.println("Dresses displayed");
		}
		
		
		@Given("user is on search page")
		public void user_is_on_search_page() {
		    // Write code here that turns the phrase above into concrete actions
		    driver.get("https://www.zara.com/in/en/search");
		    driver.manage().window().maximize();
			
		}

		@And("I click on filter option")
		public void i_click_on_filter_option() {
		    // Write code here that turns the phrase above into concrete actions
		    obj.filter.click();
		}

		@Then("I should get the filter sidebar")
		public void i_should_get_the_filter_sidebar() {
		    // Write code here that turns the phrase above into concrete actions
		    System.out.println("Filter sidebar");
		    
		}

		@Then("when I filter search based on characteristics, colour, size and click on close filter button")
		public void when_i_filter_search_based_on_characteristics_colour_size_and_click_on_close_filter_button() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
		    
			//driver.switchTo().frame(obj.filterchar);
			obj.filterchar.click();
			Thread.sleep(2000);
			obj.filtercharopt.click();
			Thread.sleep(2000);
			obj.filtercolour.click();
			Thread.sleep(2000);
			obj.filtercolouropt.click();
			Thread.sleep(2000);
			obj.filtersize.click();
			Thread.sleep(2000);
			obj.filtersizeopt.click();
			Thread.sleep(2000);
			obj.closefilter.click();
		}

		@Then("filtered results should be displayed")
		public void filtered_results_should_be_displayed() {
		    // Write code here that turns the phrase above into concrete actions
		    System.out.println("Filtered results");
		}

		
		@When("I select a top and select my size")
		public void i_select_a_top_and_select_my_size() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
		    
		obj.womansectop.click();
		Thread.sleep(2000);
		obj.womentopsize.click();
			
		}

		@When("click on Add to bag button")
		public void click_on_add_to_bag_button() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
			
			Thread.sleep(2000);
			obj.addtobag.click();
		}

		@Then("top should be added to my bag")
		public void top_should_be_added_to_my_bag() {
		    // Write code here that turns the phrase above into concrete actions
			System.out.println("top added to bag");
		    throw new io.cucumber.java.PendingException();
		}
		
		
//		@Given("User is on dresses page")
//		public void user_is_on_dresses_page() {
//		    // Write code here that turns the phrase above into concrete actions
//			driver.get("https://www.zara.com/in/en/woman-dresses-l1066.html?v1=2184287");
//			driver.findElement(By.xpath("//*[contains(@class,'onetrust-close-btn-handler banner-close-button ot-close-icon')]")).click();
//			driver.findElement(By.xpath("//*[contains(@id,'product-size-selector-231511324-toggle-button')]")).click();
//			driver.findElement(By.xpath("//*[contains(@id,'product-size-selector-231511324-item-1')]")).click();
//		    throw new io.cucumber.java.PendingException();
//		}
		
		
		@When("I click on bag icon")
		public void i_click_on_bag_icon() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
			Thread.sleep(2000);
		   obj.bag.click();
		}

		@Then("I should see items in my bag")
		public void i_should_see_items_in_my_bag() {
		    // Write code here that turns the phrase above into concrete actions
		    System.out.println("Items in the bag");
		}
		
		@When("I click on info and contact us")
		public void i_click_on_info_and_contact_us() {
		    // Write code here that turns the phrase above into concrete actions
			driver.findElement(By.xpath("//*[@id=\"sidebar\"]/div/div/nav/div/ul/li[1]/ul/li[29]/a/span")).click();
			driver.findElement(By.xpath("//*[@id=\"sidebar\"]/div/div/nav/div/ul/li[1]/ul/li[29]/ul/li[2]/a/span")).click();
			
			
		    throw new io.cucumber.java.PendingException();
		}

		@Then("contact us page should be displayed")
		public void contact_us_page_should_be_displayed() {
		    // Write code here that turns the phrase above into concrete actions
		    throw new io.cucumber.java.PendingException();
		}
		
		@Given("User is on contact us page")
		public void user_is_on_contact_us_page() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
			
			driver.get("https://www.zara.com/in/en/contact?v1=11113");
			driver.manage().window().maximize();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[contains(@class,'onetrust-close-btn-handler banner-close-button ot-close-icon')]")).click();
			Thread.sleep(2000);
		    
		}

		@When("user clicks on access button and order tracking")
		public void user_clicks_on_access_button_and_order_tracking() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
			
			driver.findElement(By.xpath("//*[contains(button,'Access')]")).click();
			driver.findElement(By.xpath("//*[contains(text(),'Order tracking')]")).click();
			Thread.sleep(4000);

		}

		@Then("zara chatbot should appear")
		public void zara_chatbot_should_appear() {
		    // Write code here that turns the phrase above into concrete actions
			
			System.out.println("chatbot appears");
			
		    
		}

		@And("user types message")
		public void user_types_message() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
			
			driver.findElement(By.xpath("//*[contains(@name,'chat-message-box')]")).sendKeys("where is my order");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[contains(@type,'submit')]")).click();

		}

		@Then("reply should be generated")
		public void reply_should_be_generated() {
		    // Write code here that turns the phrase above into concrete actions
			
			System.out.println("reply generated");
		    throw new io.cucumber.java.PendingException();
		}

	

}
