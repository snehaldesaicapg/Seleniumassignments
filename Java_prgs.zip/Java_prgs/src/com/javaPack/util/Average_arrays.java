package com.javaPack.util;

import java.util.Scanner;

public class Average_arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter num");
		int num = sc.nextInt();
		int a[] = new int[num];
		int sum=0;
		int avg= 0 ;
		
		System.out.println("Enter all nums");
		for(int i=0;i<num;i++)
		{
			a[i] = sc.nextInt();
			sum = sum+a[i];
		}
		
		avg = sum/num;
		System.out.println((avg));	
	}

}
