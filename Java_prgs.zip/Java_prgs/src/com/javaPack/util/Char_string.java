package com.javaPack.util;

public class Char_string {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char c = 'S';
		String str = Character.toString(c);
		System.out.println(str);
		
		String str1 = "Catto";
		char a[] = new char[str1.length()];
		
		for(int i=0;i<str1.length();i++)
		{
			a[i] = str1.charAt(i);
		}
		
		for(int i=0;i<str1.length();i++)
		{
			System.out.print(a[i]);
		}
		
		
	}

}
