package com.javaPack.util;

import java.util.Scanner;

public class Concat_array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		int a1[] = {1,3,4,7};
		int a2[] = {8,2,6,5};
		int res[] = new int[a1.length + a2.length];
		
		for(int i=0;i<a1.length;i++)
		{
			res[i] = a1[i];
		}
		
		for(int i=0;i<a2.length;i++)
		{
			res[a1.length+i] = a2[i];
		}
	      
		for(int i=0;i<res.length;i++)
		{
			System.out.print(res[i]);
		}
	}
}
