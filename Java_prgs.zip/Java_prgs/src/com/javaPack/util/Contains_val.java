package com.javaPack.util;

import java.util.Scanner;

public class Contains_val {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		int a[] = {12,44,65,2,68};
		int val = 65;
		int flag=0;
		
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==val)
			{
				flag=1;
				break;
			}	
		}
		
		if(flag==1)
		{
			System.out.println(val+" is present");
		}
		else
		{
			System.out.println(val+" not present");
		}	
	}
}
