package com.javaPack.util;
import java.util.*;

public class Even_odd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num = 12;
		
		if(num%2 == 0)
		{
			System.out.println(num+" is even");
		}
		else
		{
			System.out.println(num+" is odd");
		}
	}

}
