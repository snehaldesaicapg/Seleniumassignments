package com.javaPack.util;
import java.util.*;

class Parent1{
	 
	 void func() 
	 { 
	    System.out.println("Parent");
    }
}

class Child1 extends Parent1{
	 
	 void hello()
	 {
		 System.out.println("Hello child");
	 }
}

public class Inheritance1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Parent1 obj1 = new Parent1();
		Parent1 obj2 = new Child1();
		obj1.func();
		((Child1)obj2).hello();
		
	}

}
