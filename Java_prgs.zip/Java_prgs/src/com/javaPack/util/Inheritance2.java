package com.javaPack.util;
import java.util.*;

class Parent2{
	 
	 void func() 
	 { 
	    System.out.println("Parent");
   }
}

class Child2 extends Parent2{
	
    
	void func() 
	 { 
	    System.out.println("Child");
     }
	
	 void hello()
	 {
		 System.out.println("Hello child");
	 }
}

public class Inheritance2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Child2 obj2 = new Child2();
		
		obj2.func();
	}

}
