package com.javaPack.util;
import java.util.*;

class Parent3{
	 
	 void func() 
	 { 
	    System.out.println("Parent");
  }
}

class Child3 extends Parent3{
	
	
	
	void func() 
	 { 
		super.func();
	    System.out.println("Child");
     }
	
	 void hello()
	 {
		 System.out.println("Hello child");
	 }
	 
	 
}

public class Inheritance3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Child3 obj3 = new Child3();
		obj3.func();
		
	}

}
