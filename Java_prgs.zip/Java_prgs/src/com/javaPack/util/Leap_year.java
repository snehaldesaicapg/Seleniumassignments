package com.javaPack.util;
import java.util.*;

public class Leap_year {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter year:");
		int year = sc.nextInt();
		int flag=0;
		
		if(year%4 == 0)
		{
			if(year%100 == 0)
			{
				if(year%400 == 0)
				{
					flag=1;
				}
				else
				{
					flag=0;
				}
			}
			else
			{
				flag = 1;
			}
		}
		
		if(flag==1)
		{
			System.out.println(year+" is a leap year");
		}
		else
		{
			System.out.println(year+" is not a leap year");
		}
		
		
	}

}
