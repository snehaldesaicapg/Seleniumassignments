package com.javaPack.util;

import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class List_join {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Scanner sc = new Scanner(System.in);
		List<String>list1 = new ArrayList<String>();
		list1.add("a");
		
		List<String>list2 = new ArrayList<String>();
		list2.add("s");
		
		List<String>res = new ArrayList<String>();
		res.addAll(list1);
		res.addAll(list2);
		
		System.out.println(res);	
	}

}
