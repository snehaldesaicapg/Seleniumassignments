package com.javaPack.util;

import java.util.*;
import java.util.Scanner;

public class Listto_array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Scanner sc = new Scanner(System.in);
		
		List<String>list1 = new ArrayList<String>();
		list1.add("a");
		list1.add("b");
		list1.add("c");
		list1.add("d");
		
		String a[] = new String[list1.size()];
		
		for(int i=0;i<list1.size();i++)
		{
			a[i] = list1.get(i);
		}
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		
	}

}
