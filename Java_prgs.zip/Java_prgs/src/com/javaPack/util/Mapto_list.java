package com.javaPack.util;
import java.util.*;

public class Mapto_list {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<Integer, String>map = new HashMap<>();
		map.put(1, "Hello");
		map.put(2, "Hey");
		map.put(3, "Cute");
		map.put(4, "Fellow");
		
		List<Integer>keylist = new ArrayList(map.keySet());
		List<String>valuelist = new ArrayList(map.values());
		
		System.out.println(keylist);
		System.out.println(valuelist);
		
	}

}
