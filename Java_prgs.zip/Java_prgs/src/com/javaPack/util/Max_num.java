package com.javaPack.util;

import java.util.Scanner;

public class Max_num {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		int a[] = {23,11,45,66,32,87};
		int max=0;
		
		for(int i=0;i<a.length;i++)
		{
			max = a[i]>max?a[i]:max;
		}
		
		System.out.println(max);
	}

}
