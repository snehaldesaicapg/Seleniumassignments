package com.javaPack.util;
import java.util.*;

public class Multiple_table {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number");
		int num = sc.nextInt();
		int mult;
		
		for(int i=0;i<=10;i++)
		{
			mult = num*i;
			System.out.println(mult);
		}
		
		
	}

}
