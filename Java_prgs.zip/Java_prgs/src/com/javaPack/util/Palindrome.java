package com.javaPack.util;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string");
		String str = sc.next();
		String str1 = "";
		
		for(int i=str.length()-1;i>=0;i--) 
		{
	      str1 = str1 + str.charAt(i);
		}
		
		if(str.equals(str1))
		{
			System.out.println("String is palindrome");
		}
		else
		{
			System.out.println("Not palindrome");
		}
		
	}

}
