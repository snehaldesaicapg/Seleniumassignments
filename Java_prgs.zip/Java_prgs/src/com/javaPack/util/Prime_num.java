package com.javaPack.util;

import java.util.Scanner;

public class Prime_num {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int flag=0;
		System.out.println("Enter number:");
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        
        for(int i=2;i<num/2;i++)
        {
           if(num%i == 0)
           {
        	   flag=1;
        	   break;
           }	
        }
        
        if(flag==1)
        {
        	System.out.println(num+ " is not prime");
        }
        else if(flag==0)
        {
        	System.out.println(num+ " is prime");
        } 
	}

}
