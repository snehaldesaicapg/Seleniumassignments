package com.javaPack.util;
import java.util.*;

public class Reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "Hello World";
		String rev = reversestr(str);
		System.out.print(rev);
		
	}
	
	public static String reversestr(String s)
	{
		if(s.isEmpty())
		return(s);
		
		return reversestr(s.substring(1))+ s.charAt(0);
	}

}
