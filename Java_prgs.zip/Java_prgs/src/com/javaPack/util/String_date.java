package com.javaPack.util;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class String_date {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub

		String dates = "21/10/2022";
		
		SimpleDateFormat obj = new SimpleDateFormat("dd/mm/yyyy");
		Date date = obj.parse(dates) ;
		System.out.println(date);
		
	}

}
