package com.javaPack.util;
import java.util.*;

 class Parent{
	 
	 void func() 
	 { 
	    System.out.println("Parent");
     }
 }
 
 class Child extends Parent{
	 
	 void hello()
	 {
		 System.out.println("Hello child");
	 }
 }
	

public class TestInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Child obj = new Child();
		obj.func();
		obj.hello();
		
	}

}
