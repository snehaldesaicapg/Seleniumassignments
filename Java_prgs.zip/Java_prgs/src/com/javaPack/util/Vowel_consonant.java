package com.javaPack.util;
import java.util.*;

public class Vowel_consonant {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "Hi Welcome to Tutorialspoint";
		int countv=0;
		int countc=0;
		
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='a'|| str.charAt(i)=='e'|| str.charAt(i)=='i'|| str.charAt(i)=='o'|| str.charAt(i)=='u')
			{
				countv++;
			}
			else
			{
				countc++;
			}
		}
		
		System.out.println(countv);
		System.out.println(countc);
		
	}

}
