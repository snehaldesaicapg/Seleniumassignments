package com.javaPack.util;
import java.util.*;

public class alphabet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter character");
		char c =  sc.next().charAt(0);
		
		if((c>='a' && c<='z')||(c>='A'&&c<='Z'))
		{
			System.out.println(c+" is a character");
		}
		else
		{
			System.out.println(c+" is not a character");
		}
	}

}
