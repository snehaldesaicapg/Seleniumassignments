package com.javaPack.util;

import java.util.Scanner;

public class fib_series {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter count:");
		int num = sc.nextInt();
		int i=0;
		int j=1;
		int k;
		
		System.out.println(i);
		System.out.println(j);
		for(int a=0;a<num;a++)
		{
			k=i+j;
			System.out.println(k);
			i=j;
			j=k;	
		}
	}

}
